
export interface GroundingChunk {
  web: {
    uri: string;
    title: string;
  };
}

import React, { useState, useEffect, useRef } from 'react';
import { PREDEFINED_PROMPTS } from './constants';
import { pythonAgentCode } from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';

declare global {
  interface Window {
    loadPyodide: (config: { indexURL: string }) => Promise<any>;
  }
}

const App: React.FC = () => {
  const [url, setUrl] = useState<string>('');
  const [customInstructions, setCustomInstructions] = useState<string>('');
  const [selectedPrompts, setSelectedPrompts] = useState<string[]>([]);
  
  const [status, setStatus] = useState('Initializing Python Agent...');
  const [isReady, setIsReady] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');

  const pyodideRef = useRef<any>(null);

  useEffect(() => {
    const loadPyodideAndPackages = async () => {
      try {
        pyodideRef.current = await window.loadPyodide({
            indexURL: "https://cdn.jsdelivr.net/pyodide/v0.25.1/full/"
        });
        setStatus('Loading Python packages...');
        await pyodideRef.current.loadPackage('micropip');
        const micropip = pyodideRef.current.pyimport('micropip');
        await micropip.install('google-generativeai');
        
        setStatus('Python Agent is Ready');
        setIsReady(true);
      } catch (e: any) {
        console.error("Pyodide loading error:", e);
        setStatus('Failed to load Python environment.');
        setError(`Could not initialize the Python agent: ${e.message}. Please refresh the page.`);
      }
    };
    loadPyodideAndPackages();
  }, []);

  const handleGenerateReport = async () => {
    if (!url) {
      setError('Please enter a website URL to begin.');
      return;
    }
    setIsLoading(true);
    setError('');
    setOutput('');

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error("API_KEY is not configured in the environment.");
      }

      await pyodideRef.current.runPythonAsync(pythonAgentCode);
      const agentRunner = pyodideRef.current.globals.get('generate_discovery_report');
      const result = await agentRunner(apiKey, url, customInstructions, JSON.stringify(selectedPrompts));
      setOutput(result);
      
    } catch (e: any) {
      console.error("Agent execution error:", e);
      setError(`An unexpected error occurred while running the agent: ${e.message}`);
      setOutput(e.toString());
    } finally {
      setIsLoading(false);
    }
  };

  const handlePromptToggle = (prompt: string) => {
    setSelectedPrompts(prev =>
      prev.includes(prompt) ? prev.filter(p => p !== prompt) : [...prev, prompt]
    );
  };
  
  const agentReady = isReady && !isLoading;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-8 py-4">
            <h1 className="text-2xl font-bold text-brand-primary">Python Discovery Agent</h1>
            <p className="text-slate-500 text-sm">Enter a URL to generate an account discovery report using a Python agent.</p>
        </div>
      </header>
      <main className="container mx-auto p-4 md:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 space-y-8">
            {/* Input Form */}
            <div>
              <h2 className="text-xl font-semibold text-slate-700 mb-3">1. Target Website</h2>
              <input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="e.g., https://www.example.com" disabled={!agentReady} className="w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-secondary focus:border-brand-secondary transition-shadow duration-200 disabled:opacity-50 disabled:cursor-not-allowed" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-slate-700 mb-3">2. Discovery Areas</h2>
              <div className="grid grid-cols-2 gap-3">
                {PREDEFINED_PROMPTS.map(prompt => (
                  <button key={prompt} onClick={() => handlePromptToggle(prompt)} disabled={!agentReady} className={`text-left text-sm px-4 py-2 rounded-lg border transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${selectedPrompts.includes(prompt) ? 'bg-brand-primary text-white border-brand-primary font-semibold shadow-md' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'}`}>
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-semibold text-slate-700 mb-3">3. Custom Instructions</h2>
              <textarea value={customInstructions} onChange={(e) => setCustomInstructions(e.target.value)} placeholder="e.g., 'Focus on their recent AI product launches...'" rows={4} disabled={!agentReady} className="w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-secondary focus:border-brand-secondary transition-shadow duration-200 disabled:opacity-50" />
            </div>
            <button onClick={handleGenerateReport} disabled={!agentReady} className="w-full bg-brand-secondary hover:bg-brand-dark text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 ease-in-out shadow-lg hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-blue-300 disabled:bg-slate-400 disabled:cursor-not-allowed disabled:shadow-none flex items-center justify-center">
              {isLoading ? 'Agent is Working...' : (isReady ? 'Run Python Agent' : status)}
            </button>
        </div>

        {/* Output Display */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
            {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4" role="alert"><strong className="font-bold">Error: </strong><span className="block sm:inline">{error}</span></div>}
            
            {output ? (
                 <div className="prose prose-slate max-w-none h-[70vh] overflow-y-auto">
                    <MarkdownRenderer content={output} />
                 </div>
            ) : (
                <div className="text-center flex flex-col items-center justify-center h-full">
                    <div className="w-16 h-16 bg-brand-light text-brand-dark rounded-full flex items-center justify-center mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                    </div>
                    <h2 className="text-xl font-semibold text-slate-700">Agent Output</h2>
                    <p className="text-slate-500 mt-2">{isLoading ? status : 'Results from the Python agent will appear here.'}</p>
                </div>
            )}
        </div>
      </main>
    </div>
  );
};

export default App;


export const PREDEFINED_PROMPTS: string[] = [
  'Company Overview & Mission',
  'Key Products & Services Analysis',
  'Target Audience & Market Positioning',
  'Recent News & Company Updates',
  'Leadership Team & Key Personnel',
  'Pricing & Business Model',
  'Competitor Landscape',
  'Potential Pain Points & Needs'
];

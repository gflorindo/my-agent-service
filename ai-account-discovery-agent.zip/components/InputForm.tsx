
import React from 'react';
import { PREDEFINED_PROMPTS } from '../constants';

interface InputFormProps {
  url: string;
  setUrl: (url: string) => void;
  customInstructions: string;
  setCustomInstructions: (instructions: string) => void;
  selectedPrompts: string[];
  // FIX: Updated type to allow functional state updates, which is the idiomatic way to handle state changes that depend on the previous state.
  setSelectedPrompts: React.Dispatch<React.SetStateAction<string[]>>;
  onGenerate: () => void;
  isLoading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({
  url,
  setUrl,
  customInstructions,
  setCustomInstructions,
  selectedPrompts,
  setSelectedPrompts,
  onGenerate,
  isLoading,
}) => {
  const handlePromptToggle = (prompt: string) => {
    setSelectedPrompts(prev =>
      prev.includes(prompt) ? prev.filter(p => p !== prompt) : [...prev, prompt]
    );
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-slate-700 mb-3">1. Target Website</h2>
        <div className="relative">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="e.g., https://www.example.com"
            disabled={isLoading}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-secondary focus:border-brand-secondary transition-shadow duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-slate-700 mb-3">2. Discovery Areas</h2>
        <p className="text-sm text-slate-500 mb-4">Select predefined areas to guide the analysis.</p>
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-2 gap-3">
          {PREDEFINED_PROMPTS.map(prompt => (
            <button
              key={prompt}
              onClick={() => handlePromptToggle(prompt)}
              disabled={isLoading}
              className={`text-left text-sm px-4 py-2 rounded-lg border transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${
                selectedPrompts.includes(prompt)
                  ? 'bg-brand-primary text-white border-brand-primary font-semibold shadow-md'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50 hover:border-slate-400'
              }`}
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold text-slate-700 mb-3">3. Custom Instructions</h2>
         <p className="text-sm text-slate-500 mb-4">Add specific questions or instructions for the agent.</p>
        <textarea
          value={customInstructions}
          onChange={(e) => setCustomInstructions(e.target.value)}
          placeholder="e.g., 'Focus on their recent AI product launches and their target market.'"
          rows={4}
          disabled={isLoading}
          className="w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-secondary focus:border-brand-secondary transition-shadow duration-200 disabled:opacity-50"
        />
      </div>

      <div>
        <button
          onClick={onGenerate}
          disabled={isLoading}
          className="w-full bg-brand-secondary hover:bg-brand-dark text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 ease-in-out shadow-lg hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-blue-300 disabled:bg-slate-400 disabled:cursor-not-allowed disabled:shadow-none flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing...
            </>
          ) : (
            'Generate Discovery Report'
          )}
        </button>
      </div>
    </div>
  );
};

export default InputForm;
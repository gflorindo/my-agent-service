import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const renderLine = (line: string, index: number) => {
    // Headings
    if (line.startsWith('### ')) {
      return <h3 key={index} className="text-lg font-semibold mt-4 mb-2">{line.substring(4)}</h3>;
    }
    if (line.startsWith('## ')) {
      return <h2 key={index} className="text-xl font-bold mt-6 mb-3 border-b pb-2">{line.substring(3)}</h2>;
    }
    if (line.startsWith('# ')) {
      return <h1 key={index} className="text-2xl font-bold mt-8 mb-4 border-b-2 pb-2">{line.substring(2)}</h1>;
    }

    // Unordered list
    if (line.startsWith('* ') || line.startsWith('- ')) {
      return <li key={index} className="ml-5 list-disc">{renderInlineFormatting(line.substring(2))}</li>;
    }
    
    // Ordered list
    const orderedMatch = line.match(/^(\d+)\.\s(.*)/);
    if (orderedMatch) {
       return <li key={index} className="ml-5 list-decimal">{renderInlineFormatting(orderedMatch[2])}</li>;
    }

    // Paragraph
    if (line.trim() !== '') {
      return <p key={index} className="my-2">{renderInlineFormatting(line)}</p>;
    }

    return null;
  };

  const renderInlineFormatting = (text: string) => {
    // Bold text: **text**
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i}>{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  const lines = content.split('\n');
  const elements = [];
  // FIX: Corrected listItems type to string[] as it only holds strings. This resolves the 'Cannot find namespace JSX' error.
  let listItems: string[] = [];
  let listType: 'ul' | 'ol' | null = null;
  
  const closeList = () => {
    if (listItems.length > 0) {
      if (listType === 'ul') {
        // FIX: Removed unnecessary 'as string' cast due to corrected listItems type.
        elements.push(<ul key={`ul-${elements.length}`} className="space-y-1">{listItems.map((item, i) => renderLine(item, i))}</ul>);
      } else if (listType === 'ol') {
        // FIX: Removed unnecessary 'as string' cast due to corrected listItems type.
         elements.push(<ol key={`ol-${elements.length}`} className="space-y-1">{listItems.map((item, i) => renderLine(item, i))}</ol>);
      }
      listItems = [];
      listType = null;
    }
  };

  lines.forEach((line) => {
    const isUl = line.startsWith('* ') || line.startsWith('- ');
    const isOl = /^\d+\.\s/.test(line);

    if (isUl) {
      if (listType !== 'ul') {
        closeList();
        listType = 'ul';
      }
      listItems.push(line);
    } else if (isOl) {
      if (listType !== 'ol') {
        closeList();
        listType = 'ol';
      }
      listItems.push(line);
    }
     else {
      closeList();
      elements.push(renderLine(line, elements.length));
    }
  });
  
  closeList();

  return <>{elements}</>;
};

export default MarkdownRenderer;

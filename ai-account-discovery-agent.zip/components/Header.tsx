
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-slate-200">
      <div className="container mx-auto px-4 md:px-8 py-4 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-brand-primary">
            AI Account Discovery Agent
          </h1>
          <p className="text-slate-500 text-sm">
            Unlock deep insights with intelligent web analysis.
          </p>
        </div>
      </div>
    </header>
  );
};

export default Header;

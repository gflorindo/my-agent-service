
import React, { useState } from 'react';
import type { GroundingChunk } from '../types';
import LoadingSpinner from './LoadingSpinner';
import MarkdownRenderer from './MarkdownRenderer';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';

interface ResultsDisplayProps {
  result: string | null;
  sources: GroundingChunk[] | null;
  isLoading: boolean;
  error: string | null;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, sources, isLoading, error }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (result) {
      navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return <LoadingSpinner />;
    }
    if (error) {
      return (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      );
    }
    if (result) {
      return (
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 relative">
          <div className="prose prose-slate max-w-none">
             <div className="flex justify-between items-center mb-4 border-b pb-2">
               <h2 className="text-2xl font-bold text-brand-primary m-0">Discovery Report</h2>
               <button onClick={handleCopy} className="p-2 rounded-md hover:bg-slate-100 transition-colors text-slate-500 hover:text-slate-800">
                  {copied ? <CheckIcon /> : <ClipboardIcon />}
                </button>
            </div>
            <MarkdownRenderer content={result} />
          </div>

          {sources && sources.length > 0 && (
            <div className="mt-8 pt-6 border-t border-slate-200">
              <h3 className="text-lg font-semibold text-slate-700 mb-3">Sources</h3>
              <ul className="space-y-2">
                {sources.map((source, index) => (
                  <li key={index} className="flex items-start">
                    <span className="bg-slate-200 text-slate-600 text-xs font-semibold mr-3 px-2 py-1 rounded-full mt-1">{index + 1}</span>
                    <a
                      href={source.web.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-brand-secondary hover:text-brand-dark hover:underline break-all"
                      title={source.web.title}
                    >
                      {source.web.title || source.web.uri}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      );
    }
    return (
      <div className="bg-white/50 border-2 border-dashed border-slate-300 rounded-2xl h-full flex flex-col items-center justify-center text-center p-8">
         <div className="w-16 h-16 bg-brand-light text-brand-dark rounded-full flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
        </div>
        <h2 className="text-xl font-semibold text-slate-700">Your report will appear here</h2>
        <p className="text-slate-500 mt-2 max-w-md">
          Fill in the details on the left and click "Generate Discovery Report" to begin the analysis.
        </p>
      </div>
    );
  };

  return <div>{renderContent()}</div>;
};

export default ResultsDisplay;
